﻿using GalaSoft.MvvmLight;

namespace Gesca.ViewModel
{
    public partial class CashierViewModel:ObservableObject
    {
    }
}
 