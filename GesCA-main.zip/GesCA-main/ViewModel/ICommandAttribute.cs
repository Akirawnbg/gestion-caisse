﻿namespace Gesca.ViewModel
{
    internal class ICommandAttribute : Attribute
    {
    }
}